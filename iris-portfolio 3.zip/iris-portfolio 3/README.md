# Iris Portfolio

教育ライター「アイリス」のポートフォリオサイトです。  
GitHub Pages にアップロードすることで、クラウドワークスなどでの紹介ページとして利用できます。

## 公開手順
1. GitHub で新しいリポジトリ `iris-portfolio` を作成
2. このフォルダの中身をアップロード
3. Settings → Pages → Source で `main / root` を選択して保存
4. 数分後、以下のURLで公開されます：
   https://あなたのユーザー名.github.io/iris-portfolio
